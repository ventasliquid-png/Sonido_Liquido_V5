# Init pedidos module
